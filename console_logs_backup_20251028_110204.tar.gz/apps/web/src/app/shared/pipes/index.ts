/**
 * Barrel file para pipes compartidos
 */
export * from './money.pipe';
export * from './date-format.pipe';
