import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import type { WithdrawalRequest, WithdrawalStatus } from '../../../core/models/wallet.model';

/**
 * Componente para mostrar historial de retiros
 */
@Component({
  selector: 'app-withdrawal-history',
  standalone: true,
  imports: [CommonModule, TranslateModule],
  templateUrl: './withdrawal-history.component.html',
  styleUrl: './withdrawal-history.component.css',
})
export class WithdrawalHistoryComponent {
  @Input({ required: true }) requests: WithdrawalRequest[] = [];
  @Input() loading = false;

  @Output() cancelRequest = new EventEmitter<string>();
  @Output() refresh = new EventEmitter<void>();

  getStatusLabel(status: WithdrawalStatus): string {
    const labels: Record<WithdrawalStatus, string> = {
      pending: 'Pendiente',
      approved: 'Aprobado',
      processing: 'Procesando',
      completed: 'Completado',
      failed: 'Fallido',
      rejected: 'Rechazado',
      cancelled: 'Cancelado',
    };
    return labels[status] || status;
  }

  getStatusClass(status: WithdrawalStatus): string {
    const classes: Record<WithdrawalStatus, string> = {
      pending: 'bg-warning-100 text-warning-900',
      approved: 'bg-info-100 text-info-900',
      processing: 'bg-info-100 text-info-900',
      completed: 'bg-success-100 text-success-900',
      failed: 'bg-error-100 text-error-900',
      rejected: 'bg-error-100 text-error-900',
      cancelled: 'bg-neutral-100 text-neutral-900',
    };
    return classes[status] || 'bg-neutral-100 text-neutral-900';
  }

  getStatusIcon(status: WithdrawalStatus): string {
    const icons: Record<WithdrawalStatus, string> = {
      pending: '⏳',
      approved: '✓',
      processing: '⚙️',
      completed: '✅',
      failed: '❌',
      rejected: '🚫',
      cancelled: '⊗',
    };
    return icons[status] || '•';
  }

  canCancel(request: WithdrawalRequest): boolean {
    return request.status === 'pending';
  }

  onCancel(requestId: string): void {
    if (confirm('¿Estás seguro de que querés cancelar esta solicitud de retiro?')) {
      this.cancelRequest.emit(requestId);
    }
  }

  onRefresh(): void {
    this.refresh.emit();
  }

  formatDate(dateStr: string): string {
    return new Date(dateStr).toLocaleDateString('es-AR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
}
